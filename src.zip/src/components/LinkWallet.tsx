import { useLinkWallet } from "../hooks/useLinkWallet";
import { useAccount } from "wagmi";
import { useState } from "react";
import ErrorAlert from "./ErrorAlert";

export default function LinkWallet() {
    const { address } = useAccount();
    const { linkWallet, loading, error } = useLinkWallet();
    const [dismissedError, setDismissedError] = useState(false);
    const [inputAddress, setInputAddress] = useState("");

    if (error && !dismissedError) {
        return (
            <div className="max-w-md mx-auto">
                <ErrorAlert
                    error={error}
                    onDismiss={() => setDismissedError(true)}
                    showDetails={false}
                />
            </div>
        );
    }

    if (loading) {
        return (
            <div className="flex justify-center">
                <div className="w-full overflow-x-auto">
                    <div className="relative group">
                        <div className="absolute inset-0 bg-cyan-400 rounded-3xl blur-xl opacity-20 transition-opacity duration-300" />
                        <div className="relative">
                            <div className="w-fit min-w-full bg-cyan-50 dark:bg-cyan-950 rounded-3xl overflow-hidden border-2 border-cyan-200 dark:border-cyan-800 shadow-2xl">
                                <div className="h-2 bg-cyan-500" />
                                <div className="p-8 sm:p-12 flex flex-col items-center justify-center space-y-4">
                                    <div className="flex gap-2">
                                        <span className="w-2.5 h-2.5 bg-cyan-500 rounded-full animate-bounce [animation-delay:-0.3s]" />
                                        <span className="w-2.5 h-2.5 bg-cyan-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
                                        <span className="w-2.5 h-2.5 bg-cyan-500 rounded-full animate-bounce" />
                                    </div>
                                    <p className="text-sm font-semibold text-cyan-600 dark:text-cyan-400 uppercase tracking-wider">
                                        Linking Wallet…
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="flex justify-center">
            <div className="w-full overflow-x-auto">
                <div className="relative group">
                    {/* Glow */}
                    <div className="absolute inset-0 bg-violet-400 rounded-3xl blur-xl opacity-20 group-hover:opacity-30 transition-opacity duration-300" />

                    <div className="relative">
                        <div className="w-fit min-w-full bg-violet-50 dark:bg-violet-950 rounded-3xl overflow-hidden border-2 border-violet-200 dark:border-violet-800 shadow-2xl">
                            {/* Top accent bar */}
                            <div className="h-2 bg-violet-500" />

                            <div className="p-8 sm:p-12 space-y-8">
                                {/* Header */}
                                <div className="space-y-2">
                                    <p className="text-sm font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wider">
                                        ⛓ Link Wallet
                                    </p>
                                    <h3 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
                                        Connect a Wallet Address
                                    </h3>
                                    <p className="text-sm text-slate-500 dark:text-slate-400">
                                        Enter the wallet address you want to link to your identity.
                                    </p>
                                </div>

                                {/* Input form */}
                                <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 space-y-4">
                                    <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
                                        Wallet Address
                                    </p>
                                    <div className="flex flex-col sm:flex-row gap-3">
                                        <input
                                            type="text"
                                            value={inputAddress}
                                            onChange={(e) => setInputAddress(e.target.value)}
                                            placeholder="0x..."
                                            className="flex-1 min-w-0 px-4 py-3 rounded-xl text-sm font-mono bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-600 text-slate-900 dark:text-cyan-300 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-400 dark:focus:ring-violet-500 transition"
                                        />
                                        <button
                                            onClick={() => inputAddress && linkWallet(inputAddress)}
                                            disabled={!inputAddress}
                                            className="shrink-0 px-6 py-3 bg-violet-500 hover:bg-violet-600 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-xl transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-violet-400 focus:ring-offset-2"
                                        >
                                            Link Wallet
                                        </button>
                                    </div>
                                </div>

                                {/* Info stats */}
                                <div className="grid grid-cols-2 gap-4 sm:gap-6">
                                    <div className="bg-violet-100 dark:bg-violet-900 rounded-2xl p-4 border border-violet-200 dark:border-violet-700">
                                        <p className="text-xs font-semibold text-violet-700 dark:text-violet-300 uppercase tracking-wider mb-2">
                                            Connected Wallet
                                        </p>
                                        <p className="text-sm font-bold text-violet-900 dark:text-violet-100 font-mono truncate">
                                            {address ? `${address.slice(0, 6)}…${address.slice(-4)}` : "Not connected"}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}